<?php
$assets_location = base_url()."assets/bootstrap/";
$file_location = base_url()."assets/file/";
?>

 <!-- Portfolio Grid Section -->
        
    <section class="success" id="portfolio">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>Portfolio</h2>
                    <br>
                </div>
            </div>
            <div class="row">
            <?php
            foreach ($dataartikel as $row) { echo'
            
                <div class="col-sm-4 portfolio-item">
                    <a class="portfolio-link" data-toggle="modal" href="#'. $row['id_artikel'] .'">
                        <div class="caption">
                            <div class="caption-content">
                                <h1>'. $row['judul'] .'</h1>
                                <p>'. $row['intro'] .'</p>
                            </div>
                        </div>
                        <img class="img-responsive" alt="" src="'. $row['path'] .'">
                    </a>
                </div>'; } ?>
            </div>
        </div>
    </section>
    

    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-top page-scroll hidden-sm hidden-xs hidden-lg hidden-md">
        <a class="btn btn-primary" href="#beranda">
            <i class="fa fa-chevron-up"></i>
        </a>
    </div>

    <!-- Portfolio Modals -->
    <?php
    foreach($dataartikel as $row)
    { echo'
    <div tabindex="-1" role="dialog" aria-hidden="true" class="portfolio-modal modal fade" id="'. $row['id_artikel'] .'" >
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal">
                <div class="lr">
                    <div class="rl">
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="modal-body">
                            <h2>'. $row['judul'] .'</h2>
                            <hr class="star-primary">
                            <img class="img-responsive img-centered" alt="" src="'. $row['path'] .'">
                            <p>'. $row['isi'] .'</p>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>';
    } ?> 