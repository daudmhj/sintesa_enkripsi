<?php
$assets_location = base_url()."assets/bootstrap/";
$file_location = base_url()."assets/file/";
?>

    <section  id="profile">
        <div class="container">

        <!-- Introduction Row -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">About Us
                    <small>It's Nice to Meet You!</small>
                </h1>
                <h3>VISION</h3>
                <p>Actualization young generation's potential to grow the passion of work and invent a creation</p>
                <br>
                <h3>MISION</h3>
                <p>Creating an environment that can be a place to learn and evolve the skill and knowledge sustainably</p>
                <p>Give a large and fair access for young generation to get the facility to evolve self potential</p>
                <p>Organize events that could be a solution for problems which happen in a common situtation of high school and college student</p>
            </div>
        </div>

        <!-- Team Members Row -->
        <div class="row">
            <div class="col-lg-12">
                <h2 class="page-header">Our Team</h2>
            </div>
            <div class="col-lg-6 col-sm-6 text-center">
                <img class="img-circle img-responsive img-centered" src="<?php echo $file_location;?>image/Lenno.png" alt="">
                <h3>Lenno Samodra K.</h3>
                <p>Head of Marketing</p>
            </div>
            <div class="col-lg-6 col-sm-6 text-center">
                <img class="img-circle img-responsive img-centered" src="<?php echo $file_location;?>image/Mukhlis.png" alt="">
                <h3>Mukhlis Ndoyo Said</h3>
                <p>Head of Material and Conceptor</p>
            </div>
            <div class="col-lg-6 col-sm-6 text-center">
                <img class="img-circle img-responsive img-centered" src="<?php echo $file_location;?>image/Pandu.png" alt="">
                <h3>M.Rum Pandu Nuswantara</h3>
                <p>Head of Administration and Finance</p>
            </div>
            <div class="col-lg-6 col-sm-6 text-center">
                <img class="img-circle img-responsive img-centered" src="<?php echo $file_location;?>image/Adri.png" alt="">
                <h3>Adri Tria Andoko</h3>
                <p>Head of Technical</p>
            </div>
            <div class="col-lg-12 col-sm-6 text-center">
                <img class="img-circle img-responsive img-centered" src="<?php echo $file_location;?>image/Reno.png" alt="">
                <h3>Reno Albra</h3>
                <p>Brand Ambassador</p>
            </div>
            <!--<div class="col-lg-4 col-sm-6 text-center">
                <img class="img-circle img-responsive img-centered" src="<?php echo $file_location;?>image/profile.png" alt="">
                <h3>John Smith
                    <small>Job Title</small>
                </h3>
                <p>What does this team member to? Keep it short! This is also a great spot for social links!</p>
            </div>-->
        </div>
    </section>