<?php
$assets_location = base_url()."assets/bootstrap/";
$file_location = base_url()."assets/file/";
?>

<!-- Header -->
    <header>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <img class="img-responsive img-circle img-responsive img-centered" src="<?php echo $file_location;?>image/logo.png" alt="">
                    <div class="intro-text">
                        <span class="name">Sintesa Learning</span>
                        
                        <span class="skills">Training - Bedah Buku - Talkshow - Order Buku</span>
                    </div>
                </div>
            </div>
        </div>
    </header>

   