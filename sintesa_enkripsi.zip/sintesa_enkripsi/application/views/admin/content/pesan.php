
            <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Pesan
                        </h1>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>Nama</th>
                                        <th>Email</th>
                                        <th>Telepon</th>
                                        <th>Pesan</th>
                                        <th>Action</th>
                                    </tr>
                                </thead><?php
                                $no = 1;

                                foreach ($data as $row)
                                    {
                                    ?>
                                    <tr>
                                            <td> <?php echo $no;?>
                                            <td> <?php echo $row['tgl'];?></td>
                                            <?php
                                            $encrypted_text=$row['nama'];
                                            //letters of alphabet array
                                            $alphabet=array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O',
                                      			'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h',
                                      			'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', ' ',
                                      			'0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
                                            //positions of the letters in alphabet
                                            $flip=array_flip($alphabet);

                                            //plaintext array
                                            $encrypted_text=str_split($encrypted_text);
                                            $n=count($encrypted_text);
                                            $decrypted_text='';
                                            for ($i=0; $i<$n; $i++)
                                              //decryption
                                              $decrypted_text.=$alphabet[(63+$flip[$encrypted_text[$i]]-5)%63];
                                            ?>
                                            <td> <?php echo $decrypted_text;?></td>
                                            <td> <?php echo $row['email'];?></td>
                                            <?php
                                            $decrypted_text = base64_decode(urldecode($row['telepon']));
                                            ?>
                                            <td> <?php echo $decrypted_text;?></td>
                                            <td> <?php echo $row['isi'];?></td>
                                            <td>
                                                <a href="<?php echo site_url('admin/pesan/delete/'.$row['id_pesan']);?>"><button type="submit" class = "btn btn-danger fa fa-trash" title="Hapus"></button></a>
                                            </td>
                                        </tr>
                                        <?php
                                        $no++;
                                    }
                                    ?>
                                <tbody>

                                </tbody>
                            </table>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
