<?php
$assets_location = base_url()."assets/bootstrap/";

?>
    <!-- jQuery -->
    <script src="<?php echo $assets_location;?>vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo $assets_location;?>vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>