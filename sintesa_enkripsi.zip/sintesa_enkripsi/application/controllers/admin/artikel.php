<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class artikel extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct() {
		parent::__construct();
		$this->load->model("model_artikel");
	}

	public function index()
	{
        if($this->session->userdata('akses'))
        {
            $this->load->view('admin/navbar/navbar');
            $this->load->view('admin/content/tambahartikel');
            $this->load->view('admin/footer/footer');
        }else
        {
            
            $this->load->view('admin/login');
        }
	}

	public function insertArtikel()
	{
		if($this->session->userdata('akses'))
        {
			$target_Path = NULL;
			if ($_FILES['path']['name'] != NULL)
			{
				$target_Path = "assets/file/image/artikel/";
				$string = basename( $_FILES['path']['name'] );
				$string = str_replace(" ","-", $string);
				$target_Path = $target_Path.$string;
			}



			//echo $id_foto_slider.' '.$target_Path;
			//die();
			//update Foto Slider
			if($target_Path!=NULL){
				$data = array(
					'JUDUL'=> $this->input->post('judul'),
					'INTRO'=> $this->input->post('intro'),
					'ISI'=> $this->input->post('isi'),
					'PATH' => $target_Path);
					
					$query = $this->model_artikel->insert('artikel', $data);
				}
			
			//print_r($path);die();
			////////////////////////////
			if($query)
			{
				if ($target_Path != NULL) {
					move_uploaded_file( $_FILES['path']['tmp_name'], $target_Path );
				}
				echo '<script language="javascript">';
				echo 'alert("File berhasil ditambahkan");';
				echo 'window.history.go(-1);';
				echo '</script>';
			}else
			{

				echo '<script language="javascript">';
				echo 'alert("Gagal menyimpan file");';
				echo 'window.history.go(-1);';
				echo '</script>';
			}
			//redirect('admin/tambahartikel/listArtikel');
		}
	}

	public function editArtikel($id)
	{
		$this->form_validation->set_rules('judul', 'judul', 'required');
		$this->form_validation->set_rules('intro', 'intro', 'required');
		$this->form_validation->set_rules('isi', 'isi', 'required');
		if($this->form_validation->run() === FALSE)
		{
			$data['data'] = $this->model_artikel->get_data_id($id);
			$this->load->view('admin/navbar/navbar');
        	$this->load->view('admin/content/editartikel', $data);
        	$this->load->view('admin/footer/footer');
		} else {
		// mendapatkan semua data dari view
			//$this->model_artikel->edit_data($id);
			$target_Path = NULL;
			if ($_FILES['path']['name'] != NULL)
			{
				$target_Path = "assets/file/image/artikel/";
				$string = basename( $_FILES['path']['name'] );
				$string = str_replace(" ","-", $string);
				$target_Path = $target_Path.$string;
			}
			if($target_Path!=NULL)
			{
				$data = array(
					'JUDUL' => $this->input->post('judul'),
					'INTRO' => $this->input->post('intro'),
					'ISI' => $this->input->post('isi'),
					'PATH' => $target_Path
				);
				$query = $this->db->where('id_artikel', $id);
				$query = $this->db->update('artikel', $data);
				if($query)
				{
					if ($target_Path != NULL) {
						move_uploaded_file( $_FILES['path']['tmp_name'], $target_Path );
					}
					echo '<script language="javascript">';
					echo 'alert("File berhasil ditambahkan");';
					echo 'window.history.go(-1);';
					echo '</script>';
				}
				else
				{
					echo '<script language="javascript">';
					echo 'alert("Gagal menyimpan file");';
					echo 'window.history.go(-1);';
					echo '</script>';
				}
				redirect('admin/artikel/listArtikel');
			}
		}
	}

	public function listArtikel()
	{
		if($this->session->userdata('akses'))
		{
			$table = "artikel";
			$data['data'] = $this->model_artikel->gettable($table);
			$this->load->view('admin/navbar/navbar');
	        $this->load->view('admin/content/listartikel', $data);
	        $this->load->view('admin/footer/footer');
    	}
	}

	public function hapusArtikel($id)
	{
		if($this->session->userdata('akses'))
		{
			$this->model_artikel->delete_data($id);
			redirect('admin/artikel/listArtikel');
		}
	}
}
