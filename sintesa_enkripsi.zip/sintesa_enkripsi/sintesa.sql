-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2017 at 06:16 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sintesa`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
`id_admin` int(5) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`) VALUES
(1, 'admin', 'a4f2395721a4d6abfdf7dc93195d36df'),
(2, 'hashing', '34042f37fd446a35f5054cacd1d4039e');

-- --------------------------------------------------------

--
-- Table structure for table `artikel`
--

CREATE TABLE IF NOT EXISTS `artikel` (
`id_artikel` int(5) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `intro` varchar(300) NOT NULL,
  `isi` text NOT NULL,
  `path` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `artikel`
--

INSERT INTO `artikel` (`id_artikel`, `judul`, `intro`, `isi`, `path`) VALUES
(1, 'Training', 'Info Training', 'Merupakan sebuah kegiatan yang diadaptasi dari beberapa sub bab yang ditulis pada buku METAMORFOSA sendiri berisi tentang dinamika penyesuaian dan perubahan yang terjadi dari SMA menuju perkuliahan, dimana terdapat beberapa perbedaan yang mencolok, baik dari segi kebiasaan, kehidupan, model pendekatan, serta aktivitas yang berpengaruh pada proses perjalanan mahasiswa di kampus nantinya.\r\nMateri diterjemahkan sesuai dengan sasaran dari tiap-tiap Trainingnya.\r\nMateri untuk secara umum dapat dibagi dalam beberapa lingkup besar.', 'assets/file/image/artikel/cabin.png'),
(2, 'Tes2 edit ee', 'Tes Tes edit', 'Tes Tes Tes Tes Tes Tes Tes Tes Tes Tes Tes Tes Tes Tes Tes Tes Tes Tes edited EDITED', 'assets/file/image/artikel/circus.png'),
(3, 'Tes3', 'Tes Tes Tes', 'Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ', 'assets/file/image/artikel/circus.png'),
(4, 'Tes 4', 'Tes', 'lkdnalsndlajcskjabvkajvsbkjabvlablkvna;lfn;lvsjv;oaskdmalsd asd ', 'assets/file/image/artikel/submarine.png'),
(5, 'tes 5', 'asdasd', 'asfvaafasvasvd', 'assets/file/image/artikel/cabin.png'),
(6, 'artikel 6', 'tes 6', 'dsgbsfdgsdf gdfvgdfgdsgbsfdgsdf gdfvgdfg dsgbsfdgsdf gdfvgdfg', 'assets/file/image/artikel/cabin.png'),
(7, 'Tes 7', 'edit 67', 'asfs fsadfdavsd', 'assets/file/image/artikel/game.png'),
(8, 'tes 8', 'dwsfdf', 'sdgf sdvvvvvvvvdfdsf', 'assets/file/image/artikel/safe.png'),
(9, 'tes 9', 'asdfasd', 'asf vhytnuytjytj', 'assets/file/image/artikel/circus.png');

-- --------------------------------------------------------

--
-- Table structure for table `pesan`
--

CREATE TABLE IF NOT EXISTS `pesan` (
`id_pesan` int(5) NOT NULL,
  `tgl` date NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telepon` varchar(20) NOT NULL,
  `isi` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pesan`
--

INSERT INTO `pesan` (`id_pesan`, `tgl`, `nama`, `email`, `telepon`, `isi`) VALUES
(38, '2017-04-23', 'IFZI', 'tes@enkripsi.com', 'MDg1NzI5MTQ1NTQx', 'tes 1'),
(41, '2017-04-23', 'IFZIFRZMFONW', 'tes@enkripsi.com', 'MDg1NzI5MTQ1NTQx', 'tes 2'),
(42, '2017-04-23', 'GOLNIPHKLLKH', 'tes@enkripsi.com', 'MDg1NzI5MTQ1NTQx', 'tes 3'),
(43, '2017-04-23', 'Ifzi4Rzmfonw', 'tes@enkripsi.com', 'MDg1NzI5MTQ1NTQx', 'tes 3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `artikel`
--
ALTER TABLE `artikel`
 ADD PRIMARY KEY (`id_artikel`);

--
-- Indexes for table `pesan`
--
ALTER TABLE `pesan`
 ADD PRIMARY KEY (`id_pesan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `id_admin` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `artikel`
--
ALTER TABLE `artikel`
MODIFY `id_artikel` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `pesan`
--
ALTER TABLE `pesan`
MODIFY `id_pesan` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=44;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
